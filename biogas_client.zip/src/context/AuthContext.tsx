
import { createContext, useContext, useState, ReactNode } from 'react';

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Default demo user - authentication disabled
const defaultUser: User = {
  id: '1',
  name: 'Demo User',
  email: 'demo@biogas.com',
  role: 'Admin',
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user] = useState<User | null>(defaultUser);
  const [token] = useState<string | null>('demo-token');

  // Authentication disabled - login always succeeds
  const login = async (_email: string, _password: string) => {
    // No-op: authentication disabled
    return Promise.resolve();
  };

  // Authentication disabled - logout is a no-op
  const logout = () => {
    // No-op: authentication disabled
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        login,
        logout,
        isAuthenticated: true, // Always authenticated
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
