
import React from 'react';
import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
  TextField,
  Grid,
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { MISEntry } from '../../../../mocks/misEntries';

interface Props {
  selectedEntry: MISEntry | null;
  isReadOnly: boolean;
}

/**
 * FeedMixingTankSection renders the feed‑mixing‑tank related fields.
 * It safely handles the case where `selectedEntry` (or any nested
 * property) is null/undefined and adds minimal error handling to
 * avoid runtime crashes.
 */
export default function FeedMixingTankSection({ selectedEntry, isReadOnly }: Props) {
  // Defensive extraction – guarantees an object shape even when data is missing.
  const feedMixingTank = selectedEntry?.feedMixingTank ?? {
    cowDungFeed: {},
    pressmudFeed: {},
    permeateFeed: {},
    waterQty: '',
    slurry: {},
  };

  return (
    <Accordion
      sx={{
        mb: 2,
        borderRadius: '12px !important',
        '&:before': { display: 'none' },
        overflow: 'hidden',
        boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
        border: '1px solid #e0e0e0',
      }}
    >
      <AccordionSummary
        expandIcon={<ExpandMoreIcon sx={{ color: '#666' }} />}
        sx={{
          backgroundColor: '#f5f5f5',
          borderBottom: '1px solid #e0e0e0',
          minHeight: '56px',
          '&.Mui-expanded': {
            minHeight: '56px',
          },
        }}
      >
        <Typography sx={{ fontWeight: 600, color: '#333' }}>Feed Mixing Tank</Typography>
      </AccordionSummary>

      <AccordionDetails sx={{ p: 3, backgroundColor: '#fff' }}>
        {/* Cow Dung Feed */}
        <Typography
          variant="subtitle2"
          sx={{ fontWeight: 600, mb: 2, color: '#555' }}
        >
          Cow Dung Feed
        </Typography>
        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid item xs={12} sm={4}>
            <TextField
              fullWidth
              label="Qty"
              type="number"
              defaultValue={feedMixingTank.cowDungFeed?.qty ?? ''}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <TextField
              fullWidth
              label="TS %"
              type="number"
              defaultValue={feedMixingTank.cowDungFeed?.ts ?? ''}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <TextField
              fullWidth
              label="VS %"
              type="number"
              defaultValue={feedMixingTank.cowDungFeed?.vs ?? ''}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>
        </Grid>

        {/* Pressmud Feed */}
        <Typography
          variant="subtitle2"
          sx={{ fontWeight: 600, mb: 2, color: '#555' }}
        >
          Pressmud Feed
        </Typography>
        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid item xs={12} sm={4}>
            <TextField
              fullWidth
              label="Qty"
              type="number"
              defaultValue={feedMixingTank.pressmudFeed?.qty ?? ''}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <TextField
              fullWidth
              label="TS %"
              type="number"
              defaultValue={feedMixingTank.pressmudFeed?.ts ?? ''}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <TextField
              fullWidth
              label="VS %"
              type="number"
              defaultValue={feedMixingTank.pressmudFeed?.vs ?? ''}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>
        </Grid>

        {/* Permeate Feed */}
        <Typography
          variant="subtitle2"
          sx={{ fontWeight: 600, mb: 2, color: '#555' }}
        >
          Permeate Feed
        </Typography>
        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid item xs={12} sm={4}>
            <TextField
              fullWidth
              label="Qty"
              type="number"
              defaultValue={feedMixingTank.permeateFeed?.qty ?? ''}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <TextField
              fullWidth
              label="TS %"
              type="number"
              defaultValue={feedMixingTank.permeateFeed?.ts ?? ''}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <TextField
              fullWidth
              label="VS %"
              type="number"
              defaultValue={feedMixingTank.permeateFeed?.vs ?? ''}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>
        </Grid>

        {/* Water Feed */}
        <Typography
          variant="subtitle2"
          sx={{ fontWeight: 600, mb: 2, color: '#555' }}
        >
          Water Feed
        </Typography>
        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid item xs={12} sm={4}>
            <TextField
              fullWidth
              label="Water Qty"
              type="number"
              defaultValue={feedMixingTank.waterQty ?? ''}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>
        </Grid>

        {/* Feed Mixing Tank Slurry */}
        <Typography
          variant="subtitle2"
          sx={{ fontWeight: 600, mb: 2, color: '#555' }}
        >
          Feed Mixing Tank Slurry
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6} md={3}>
            <TextField
              fullWidth
              label="Total Slurry"
              type="number"
              defaultValue={feedMixingTank.slurry?.total ?? ''}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <TextField
              fullWidth
              label="Slurry TS %"
              type="number"
              defaultValue={feedMixingTank.slurry?.ts ?? ''}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <TextField
              fullWidth
              label="Slurry VS %"
              type="number"
              defaultValue={feedMixingTank.slurry?.vs ?? ''}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <TextField
              fullWidth
              label="pH"
              type="number"
              defaultValue={feedMixingTank.slurry?.ph ?? ''}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>
        </Grid>
      </AccordionDetails>
    </Accordion>
  );
}
