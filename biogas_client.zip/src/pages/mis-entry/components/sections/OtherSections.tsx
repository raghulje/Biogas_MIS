
import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
  TextField,
  Grid,
} from '@mui/material';
import { ExpandMore as ExpandMoreIcon } from '@mui/icons-material';
import { MISEntry } from '../../../../mocks/misEntries';

interface Props {
  selectedEntry: MISEntry | null;
  isReadOnly: boolean;
}

export default function OtherSections({ selectedEntry, isReadOnly }: Props) {
  return (
    <>
      {/* Fertilizer */}
      <Accordion
        sx={{
          mb: 2,
          borderRadius: '12px !important',
          '&:before': { display: 'none' },
          overflow: 'hidden',
          boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
          border: '1px solid #e0e0e0',
        }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon sx={{ color: '#666' }} />}
          sx={{
            backgroundColor: '#f5f5f5',
            borderBottom: '1px solid #e0e0e0',
            minHeight: '56px',
            '&.Mui-expanded': {
              minHeight: '56px',
            },
          }}
        >
          <Typography sx={{ fontWeight: 600, color: '#333' }}>Fertilizer</Typography>
        </AccordionSummary>
        <AccordionDetails sx={{ p: 3, backgroundColor: '#fff' }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="FOM Produced"
                type="number"
                defaultValue={selectedEntry?.fertilizer.fomProduced ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="Inventory"
                type="number"
                defaultValue={selectedEntry?.fertilizer.inventory ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="Sold"
                type="number"
                defaultValue={selectedEntry?.fertilizer.sold ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="Weighted Average"
                type="number"
                defaultValue={selectedEntry?.fertilizer.weightedAverage ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="Revenue 1"
                type="number"
                defaultValue={selectedEntry?.fertilizer.revenue1 ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="Lagoon Liquid Sold"
                type="number"
                defaultValue={selectedEntry?.fertilizer.lagoonLiquidSold ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="Revenue 2"
                type="number"
                defaultValue={selectedEntry?.fertilizer.revenue2 ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="Loose FOM Sold"
                type="number"
                defaultValue={selectedEntry?.fertilizer.looseFomSold ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="Revenue 3"
                type="number"
                defaultValue={selectedEntry?.fertilizer.revenue3 ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
          </Grid>
        </AccordionDetails>
      </Accordion>

      {/* Utilities and Power */}
      <Accordion
        sx={{
          mb: 2,
          borderRadius: '12px !important',
          '&:before': { display: 'none' },
          overflow: 'hidden',
          boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
          border: '1px solid #e0e0e0',
        }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon sx={{ color: '#666' }} />}
          sx={{
            backgroundColor: '#f5f5f5',
            borderBottom: '1px solid #e0e0e0',
            minHeight: '56px',
            '&.Mui-expanded': {
              minHeight: '56px',
            },
          }}
        >
          <Typography sx={{ fontWeight: 600, color: '#333' }}>
            Utilities and Power
          </Typography>
        </AccordionSummary>
        <AccordionDetails sx={{ p: 3, backgroundColor: '#fff' }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Electricity Consumption"
                type="number"
                defaultValue={
                  selectedEntry?.utilities.electricityConsumption ?? ''
                }
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Specific Power Consumption"
                type="number"
                defaultValue={
                  selectedEntry?.utilities.specificPowerConsumption ?? ''
                }
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
          </Grid>
        </AccordionDetails>
      </Accordion>

      {/* Manpower */}
      <Accordion
        sx={{
          mb: 2,
          borderRadius: '12px !important',
          '&:before': { display: 'none' },
          overflow: 'hidden',
          boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
          border: '1px solid #e0e0e0',
        }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon sx={{ color: '#666' }} />}
          sx={{
            backgroundColor: '#f5f5f5',
            borderBottom: '1px solid #e0e0e0',
            minHeight: '56px',
            '&.Mui-expanded': {
              minHeight: '56px',
            },
          }}
        >
          <Typography sx={{ fontWeight: 600, color: '#333' }}>Manpower</Typography>
        </AccordionSummary>
        <AccordionDetails sx={{ p: 3, backgroundColor: '#fff' }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Refex-SREL Staff"
                type="number"
                defaultValue={selectedEntry?.manpower.refexSrelStaff ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Third Party Staff"
                type="number"
                defaultValue={selectedEntry?.manpower.thirdPartyStaff ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
          </Grid>
        </AccordionDetails>
      </Accordion>

      {/* Plant Availability */}
      <Accordion
        sx={{
          mb: 2,
          borderRadius: '12px !important',
          '&:before': { display: 'none' },
          overflow: 'hidden',
          boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
          border: '1px solid #e0e0e0',
        }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon sx={{ color: '#666' }} />}
          sx={{
            backgroundColor: '#f5f5f5',
            borderBottom: '1px solid #e0e0e0',
            minHeight: '56px',
            '&.Mui-expanded': {
              minHeight: '56px',
            },
          }}
        >
          <Typography sx={{ fontWeight: 600, color: '#333' }}>
            Plant Availability
          </Typography>
        </AccordionSummary>
        <AccordionDetails sx={{ p: 3, backgroundColor: '#fff' }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6} md={3}>
              <TextField
                fullWidth
                label="Working Hours"
                type="number"
                defaultValue={selectedEntry?.plantAvailability.workingHours ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <TextField
                fullWidth
                label="Scheduled Downtime"
                type="number"
                defaultValue={selectedEntry?.plantAvailability.scheduledDowntime ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <TextField
                fullWidth
                label="Unscheduled Downtime"
                type="number"
                defaultValue={selectedEntry?.plantAvailability.unscheduledDowntime ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <TextField
                fullWidth
                label="Total Availability"
                type="number"
                defaultValue={selectedEntry?.plantAvailability.totalAvailability ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
          </Grid>
        </AccordionDetails>
      </Accordion>

      {/* HSE */}
      <Accordion
        sx={{
          mb: 2,
          borderRadius: '12px !important',
          '&:before': { display: 'none' },
          overflow: 'hidden',
          boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
          border: '1px solid #e0e0e0',
        }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon sx={{ color: '#666' }} />}
          sx={{
            backgroundColor: '#f5f5f5',
            borderBottom: '1px solid #e0e0e0',
            minHeight: '56px',
            '&.Mui-expanded': {
              minHeight: '56px',
            },
          }}
        >
          <Typography sx={{ fontWeight: 600, color: '#333' }}>HSE</Typography>
        </AccordionSummary>
        <AccordionDetails sx={{ p: 3, backgroundColor: '#fff' }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="Safety LTI"
                type="number"
                defaultValue={selectedEntry?.hse.safetyLti ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="Near Misses"
                type="number"
                defaultValue={selectedEntry?.hse.nearMisses ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="First Aid"
                type="number"
                defaultValue={selectedEntry?.hse.firstAid ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="Reportable Incidents"
                type="number"
                defaultValue={selectedEntry?.hse.reportableIncidents ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="MTI"
                type="number"
                defaultValue={selectedEntry?.hse.mti ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="Other Incidents"
                type="number"
                defaultValue={selectedEntry?.hse.otherIncidents ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="Fatalities"
                type="number"
                defaultValue={selectedEntry?.hse.fatalities ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
          </Grid>
        </AccordionDetails>
      </Accordion>

      {/* Remarks */}
      <Accordion
        sx={{
          mb: 2,
          borderRadius: '12px !important',
          '&:before': { display: 'none' },
          overflow: 'hidden',
          boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
          border: '1px solid #e0e0e0',
        }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon sx={{ color: '#666' }} />}
          sx={{
            backgroundColor: '#f5f5f5',
            borderBottom: '1px solid #e0e0e0',
            minHeight: '56px',
            '&.Mui-expanded': {
              minHeight: '56px',
            },
          }}
        >
          <Typography sx={{ fontWeight: 600, color: '#333' }}>Remarks</Typography>
        </AccordionSummary>
        <AccordionDetails sx={{ p: 3, backgroundColor: '#fff' }}>
          <TextField
            fullWidth
            label="Breakdown Reason"
            multiline
            rows={4}
            placeholder="Enter any breakdown reasons or additional remarks..."
            defaultValue={selectedEntry?.remarks ?? ''}
            disabled={isReadOnly}
            sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
          />
        </AccordionDetails>
      </Accordion>
    </>
  );
}
