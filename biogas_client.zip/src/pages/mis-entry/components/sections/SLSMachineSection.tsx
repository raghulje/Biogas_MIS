
import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
  TextField,
  Grid,
} from '@mui/material';
import { ExpandMore as ExpandMoreIcon } from '@mui/icons-material';
import { MISEntry } from '../../../../mocks/misEntries';

interface Props {
  selectedEntry: MISEntry | null;
  isReadOnly: boolean;
}

export default function SLSMachineSection({ selectedEntry, isReadOnly }: Props) {
  const slsMachine = selectedEntry?.slsMachine ?? {};

  const getValue = (key: keyof typeof slsMachine) =>
    slsMachine[key] !== undefined && slsMachine[key] !== null
      ? slsMachine[key]
      : '';

  return (
    <Accordion
      sx={{
        mb: 2,
        borderRadius: '12px !important',
        '&:before': { display: 'none' },
        overflow: 'hidden',
        boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
        border: '1px solid #e0e0e0',
      }}
    >
      <AccordionSummary
        expandIcon={<ExpandMoreIcon sx={{ color: '#666' }} />}
        sx={{
          backgroundColor: '#f5f5f5',
          borderBottom: '1px solid #e0e0e0',
          minHeight: '56px',
          '&.Mui-expanded': {
            minHeight: '56px',
          },
        }}
      >
        <Typography sx={{ fontWeight: 600, color: '#333' }}>SLS Machine</Typography>
      </AccordionSummary>

      <AccordionDetails sx={{ p: 3, backgroundColor: '#fff' }}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6} md={4}>
            <TextField
              fullWidth
              label="Water Consumption"
              type="number"
              defaultValue={getValue('waterConsumption')}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <TextField
              fullWidth
              label="Poly Electrolyte"
              type="number"
              defaultValue={getValue('polyElectrolyte')}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <TextField
              fullWidth
              label="Solution"
              type="number"
              defaultValue={getValue('solution')}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <TextField
              fullWidth
              label="Slurry Feed"
              type="number"
              defaultValue={getValue('slurryFeed')}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <TextField
              fullWidth
              label="Wet Cake Production"
              type="number"
              defaultValue={getValue('wetCakeProduction')}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <TextField
              fullWidth
              label="Wet Cake TS %"
              type="number"
              defaultValue={getValue('wetCakeTs')}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <TextField
              fullWidth
              label="Wet Cake VS %"
              type="number"
              defaultValue={getValue('wetCakeVs')}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <TextField
              fullWidth
              label="Liquid Produced"
              type="number"
              defaultValue={getValue('liquidProduced')}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <TextField
              fullWidth
              label="Liquid TS %"
              type="number"
              defaultValue={getValue('liquidTs')}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <TextField
              fullWidth
              label="Liquid VS %"
              type="number"
              defaultValue={getValue('liquidVs')}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <TextField
              fullWidth
              label="Liquid Sent to Lagoon"
              type="number"
              defaultValue={getValue('liquidSentToLagoon')}
              disabled={isReadOnly}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
          </Grid>
        </Grid>
      </AccordionDetails>
    </Accordion>
  );
}
