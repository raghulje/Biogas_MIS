
import React from 'react';
import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
  TextField,
  Grid,
  Card,
  CardContent,
  Box,
  Button,
  IconButton,
  MenuItem,
} from '@mui/material';
import {
  ExpandMore as ExpandMoreIcon,
  Add as AddIcon,
  Delete as DeleteIcon,
} from '@mui/icons-material';

interface Digester {
  id: number;
  name: string;
  feeding: { totalSlurryFeed: number; avgTs: number; avgVs: number };
  discharge: { totalSlurryOut: number; avgTs: number; avgVs: number };
  characteristics: {
    lignin: number;
    vfa: number;
    alkalinity: number;
    vfaAlkRatio: number;
    ash: number;
    density: number;
    ph: number;
    temperature: number;
    pressure: number;
    slurryLevel: number;
  };
  health: {
    hrt: number;
    vsDestruction: number;
    olr: number;
    balloonLevel: number;
    agitatorCondition: string;
    foamingLevel: number;
  };
}

interface Props {
  digesters: Digester[];
  isReadOnly: boolean;
  onAddDigester: () => void;
  onRemoveDigester: (id: number) => void;
}

export default function DigestersSection({
  digesters = [],
  isReadOnly,
  onAddDigester,
  onRemoveDigester,
}: Props) {
  const safeAdd = React.useCallback(() => {
    if (typeof onAddDigester === 'function') {
      onAddDigester();
    } else {
      console.error('DigestersSection: onAddDigester prop is not a function');
    }
  }, [onAddDigester]);

  const safeRemove = React.useCallback(
    (id: number) => {
      if (typeof onRemoveDigester === 'function') {
        onRemoveDigester(id);
      } else {
        console.error('DigestersSection: onRemoveDigester prop is not a function');
      }
    },
    [onRemoveDigester],
  );

  const hasDigesters = Array.isArray(digesters) && digesters.length > 0;

  return (
    <Accordion
      sx={{
        mb: 2,
        borderRadius: '12px !important',
        '&:before': { display: 'none' },
        overflow: 'hidden',
        boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
        border: '1px solid #e0e0e0',
      }}
    >
      <AccordionSummary
        expandIcon={<ExpandMoreIcon sx={{ color: '#666' }} />}
        sx={{
          backgroundColor: '#f5f5f5',
          borderBottom: '1px solid #e0e0e0',
          minHeight: '56px',
          '&.Mui-expanded': {
            minHeight: '56px',
          },
        }}
      >
        <Typography sx={{ fontWeight: 600, color: '#333' }}>Digesters</Typography>
      </AccordionSummary>

      <AccordionDetails sx={{ p: 3, backgroundColor: '#fff' }}>
        {!isReadOnly && (
          <Box sx={{ mb: 2 }}>
            <Button
              variant="outlined"
              startIcon={<AddIcon />}
              onClick={safeAdd}
              sx={{
                textTransform: 'none',
                borderRadius: '8px',
                borderColor: '#999',
                color: '#555',
                whiteSpace: 'nowrap',
                '&:hover': {
                  borderColor: '#666',
                  backgroundColor: 'rgba(0, 0, 0, 0.04)',
                },
              }}
            >
              Add Digester
            </Button>
          </Box>
        )}

        {hasDigesters ? (
          digesters.map((digester) => (
            <Card
              key={digester.id}
              sx={{
                mb: 2,
                borderRadius: '12px',
                border: '1px solid #e0e0e0',
                boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
              }}
            >
              <CardContent sx={{ p: 3 }}>
                <Box
                  sx={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    mb: 2,
                  }}
                >
                  <Typography
                    variant="h6"
                    sx={{ fontWeight: 600, color: '#333' }}
                  >
                    {digester.name ?? `Digester ${digester.id}`}
                  </Typography>

                  {!isReadOnly && digesters.length > 1 && (
                    <IconButton
                      onClick={() => safeRemove(digester.id)}
                      size="small"
                      sx={{
                        color: '#d32f2f',
                        backgroundColor: 'rgba(211, 47, 47, 0.08)',
                        borderRadius: '8px',
                        '&:hover': {
                          backgroundColor: 'rgba(211, 47, 47, 0.15)',
                        },
                      }}
                    >
                      <DeleteIcon />
                    </IconButton>
                  )}
                </Box>

                {/* ---- Feeding Data ---- */}
                <Typography
                  variant="subtitle2"
                  sx={{
                    fontWeight: 600,
                    mb: 2,
                    color: '#555',
                  }}
                >
                  Feeding Data
                </Typography>
                <Grid container spacing={2} sx={{ mb: 3 }}>
                  <Grid item xs={12} sm={4}>
                    <TextField
                      fullWidth
                      label="Total Slurry Feed"
                      type="number"
                      size="small"
                      defaultValue={digester.feeding?.totalSlurryFeed ?? ''}
                      disabled={isReadOnly}
                      sx={{
                        '& .MuiOutlinedInput-root': { borderRadius: '8px' },
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <TextField
                      fullWidth
                      label="Avg TS %"
                      type="number"
                      size="small"
                      defaultValue={digester.feeding?.avgTs ?? ''}
                      disabled={isReadOnly}
                      sx={{
                        '& .MuiOutlinedInput-root': { borderRadius: '8px' },
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <TextField
                      fullWidth
                      label="Avg VS %"
                      type="number"
                      size="small"
                      defaultValue={digester.feeding?.avgVs ?? ''}
                      disabled={isReadOnly}
                      sx={{
                        '& .MuiOutlinedInput-root': { borderRadius: '8px' },
                      }}
                    />
                  </Grid>
                </Grid>

                {/* ---- Discharge Data ---- */}
                <Typography
                  variant="subtitle2"
                  sx={{
                    fontWeight: 600,
                    mb: 2,
                    color: '#555',
                  }}
                >
                  Discharge Data
                </Typography>
                <Grid container spacing={2} sx={{ mb: 3 }}>
                  <Grid item xs={12} sm={4}>
                    <TextField
                      fullWidth
                      label="Total Slurry Out"
                      type="number"
                      size="small"
                      defaultValue={digester.discharge?.totalSlurryOut ?? ''}
                      disabled={isReadOnly}
                      sx={{
                        '& .MuiOutlinedInput-root': { borderRadius: '8px' },
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <TextField
                      fullWidth
                      label="Avg TS %"
                      type="number"
                      size="small"
                      defaultValue={digester.discharge?.avgTs ?? ''}
                      disabled={isReadOnly}
                      sx={{
                        '& .MuiOutlinedInput-root': { borderRadius: '8px' },
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <TextField
                      fullWidth
                      label="Avg VS %"
                      type="number"
                      size="small"
                      defaultValue={digester.discharge?.avgVs ?? ''}
                      disabled={isReadOnly}
                      sx={{
                        '& .MuiOutlinedInput-root': { borderRadius: '8px' },
                      }}
                    />
                  </Grid>
                </Grid>

                {/* ---- Slurry Characteristics ---- */}
                <Typography
                  variant="subtitle2"
                  sx={{
                    fontWeight: 600,
                    mb: 2,
                    color: '#555',
                  }}
                >
                  Slurry Characteristics
                </Typography>
                <Grid container spacing={2} sx={{ mb: 3 }}>
                  {[
                    { label: 'Lignin', key: 'lignin' },
                    { label: 'VFA', key: 'vfa' },
                    { label: 'Alkalinity', key: 'alkalinity' },
                    { label: 'VFA:ALK Ratio', key: 'vfaAlkRatio' },
                    { label: 'Ash', key: 'ash' },
                    { label: 'Density', key: 'density' },
                    { label: 'pH', key: 'ph' },
                    { label: 'Temperature', key: 'temperature' },
                    { label: 'Pressure', key: 'pressure' },
                    { label: 'Slurry Level', key: 'slurryLevel' },
                  ].map(({ label, key }) => (
                    <Grid item xs={6} sm={4} md={3} key={key}>
                      <TextField
                        fullWidth
                        label={label}
                        type="number"
                        size="small"
                        defaultValue={digester.characteristics?.[key as keyof typeof digester.characteristics] ?? ''}
                        disabled={isReadOnly}
                        sx={{
                          '& .MuiOutlinedInput-root': { borderRadius: '8px' },
                        }}
                      />
                    </Grid>
                  ))}
                </Grid>

                {/* ---- Health Monitoring ---- */}
                <Typography
                  variant="subtitle2"
                  sx={{
                    fontWeight: 600,
                    mb: 2,
                    color: '#555',
                  }}
                >
                  Health Monitoring
                </Typography>
                <Grid container spacing={2}>
                  <Grid item xs={6} sm={4} md={3}>
                    <TextField
                      fullWidth
                      label="HRT"
                      type="number"
                      size="small"
                      defaultValue={digester.health?.hrt ?? ''}
                      disabled={isReadOnly}
                      sx={{
                        '& .MuiOutlinedInput-root': { borderRadius: '8px' },
                      }}
                    />
                  </Grid>
                  <Grid item xs={6} sm={4} md={3}>
                    <TextField
                      fullWidth
                      label="VS Destruction"
                      type="number"
                      size="small"
                      defaultValue={digester.health?.vsDestruction ?? ''}
                      disabled={isReadOnly}
                      sx={{
                        '& .MuiOutlinedInput-root': { borderRadius: '8px' },
                      }}
                    />
                  </Grid>
                  <Grid item xs={6} sm={4} md={3}>
                    <TextField
                      fullWidth
                      label="OLR"
                      type="number"
                      size="small"
                      defaultValue={digester.health?.olr ?? ''}
                      disabled={isReadOnly}
                      sx={{
                        '& .MuiOutlinedInput-root': { borderRadius: '8px' },
                      }}
                    />
                  </Grid>
                  <Grid item xs={6} sm={4} md={3}>
                    <TextField
                      fullWidth
                      label="Balloon Level"
                      type="number"
                      size="small"
                      defaultValue={digester.health?.balloonLevel ?? ''}
                      disabled={isReadOnly}
                      sx={{
                        '& .MuiOutlinedInput-root': { borderRadius: '8px' },
                      }}
                    />
                  </Grid>
                  <Grid item xs={6} sm={4} md={3}>
                    <TextField
                      fullWidth
                      select
                      label="Agitator Condition"
                      defaultValue={digester.health?.agitatorCondition ?? 'OK'}
                      size="small"
                      disabled={isReadOnly}
                      sx={{
                        '& .MuiOutlinedInput-root': { borderRadius: '8px' },
                      }}
                    >
                      <MenuItem value="OK">OK</MenuItem>
                      <MenuItem value="Not OK">Not OK</MenuItem>
                    </TextField>
                  </Grid>
                  <Grid item xs={6} sm={4} md={3}>
                    <TextField
                      fullWidth
                      label="Foaming Level"
                      type="number"
                      size="small"
                      defaultValue={digester.health?.foamingLevel ?? ''}
                      disabled={isReadOnly}
                      sx={{
                        '& .MuiOutlinedInput-root': { borderRadius: '8px' },
                      }}
                    />
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          ))
        ) : (
          <Typography variant="body2" color="text.secondary">
            No digesters available.
          </Typography>
        )}
      </AccordionDetails>
    </Accordion>
  );
}
