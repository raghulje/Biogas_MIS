
import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
  TextField,
  Grid,
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { MISEntry } from '../../../../mocks/misEntries';

interface Props {
  selectedEntry: MISEntry | null;
  isReadOnly: boolean;
}

export default function BiogasSection({ selectedEntry, isReadOnly }: Props) {
  return (
    <>
      {/* Raw Biogas */}
      <Accordion
        sx={{
          mb: 2,
          borderRadius: '12px !important',
          '&:before': { display: 'none' },
          overflow: 'hidden',
          boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
          border: '1px solid #e0e0e0',
        }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon sx={{ color: '#666' }} />}
          sx={{
            backgroundColor: '#f5f5f5',
            borderBottom: '1px solid #e0e0e0',
            minHeight: '56px',
            '&.Mui-expanded': {
              minHeight: '56px',
            },
          }}
        >
          <Typography sx={{ fontWeight: 600, color: '#333' }}>Raw Biogas</Typography>
        </AccordionSummary>
        <AccordionDetails sx={{ p: 3, backgroundColor: '#fff' }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="Digester 01 Gas"
                type="number"
                defaultValue={selectedEntry?.rawBiogas.digester01Gas ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="Digester 02 Gas"
                type="number"
                defaultValue={selectedEntry?.rawBiogas.digester02Gas ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="Digester 03 Gas"
                type="number"
                defaultValue={selectedEntry?.rawBiogas.digester03Gas ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="Total Raw Biogas"
                type="number"
                defaultValue={selectedEntry?.rawBiogas.totalRawBiogas ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="RBG Flared"
                type="number"
                defaultValue={selectedEntry?.rawBiogas.rbgFlared ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="Gas Yield"
                type="number"
                defaultValue={selectedEntry?.rawBiogas.gasYield ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
          </Grid>
        </AccordionDetails>
      </Accordion>

      {/* Raw Biogas Quality */}
      <Accordion
        sx={{
          mb: 2,
          borderRadius: '12px !important',
          '&:before': { display: 'none' },
          overflow: 'hidden',
          boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
          border: '1px solid #e0e0e0',
        }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon sx={{ color: '#666' }} />}
          sx={{
            backgroundColor: '#f5f5f5',
            borderBottom: '1px solid #e0e0e0',
            minHeight: '56px',
            '&.Mui-expanded': {
              minHeight: '56px',
            },
          }}
        >
          <Typography sx={{ fontWeight: 600, color: '#333' }}>
            Raw Biogas Quality
          </Typography>
        </AccordionSummary>
        <AccordionDetails sx={{ p: 3, backgroundColor: '#fff' }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="CH4 %"
                type="number"
                defaultValue={selectedEntry?.rawBiogasQuality.ch4 ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="CO2 %"
                type="number"
                defaultValue={selectedEntry?.rawBiogasQuality.co2 ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="H2S ppm"
                type="number"
                defaultValue={selectedEntry?.rawBiogasQuality.h2s ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="O2 %"
                type="number"
                defaultValue={selectedEntry?.rawBiogasQuality.o2 ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="N2 %"
                type="number"
                defaultValue={selectedEntry?.rawBiogasQuality.n2 ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
          </Grid>
        </AccordionDetails>
      </Accordion>

      {/* Compressed Biogas */}
      <Accordion
        sx={{
          mb: 2,
          borderRadius: '12px !important',
          '&:before': { display: 'none' },
          overflow: 'hidden',
          boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
          border: '1px solid #e0e0e0',
        }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon sx={{ color: '#666' }} />}
          sx={{
            backgroundColor: '#f5f5f5',
            borderBottom: '1px solid #e0e0e0',
            minHeight: '56px',
            '&.Mui-expanded': {
              minHeight: '56px',
            },
          }}
        >
          <Typography sx={{ fontWeight: 600, color: '#333' }}>
            Compressed Biogas
          </Typography>
        </AccordionSummary>
        <AccordionDetails sx={{ p: 3, backgroundColor: '#fff' }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="Produced (kg)"
                type="number"
                defaultValue={selectedEntry?.compressedBiogas.produced ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="CH4 %"
                type="number"
                defaultValue={selectedEntry?.compressedBiogas.ch4 ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="CO2 %"
                type="number"
                defaultValue={selectedEntry?.compressedBiogas.co2 ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="H2S ppm"
                type="number"
                defaultValue={selectedEntry?.compressedBiogas.h2s ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="O2 %"
                type="number"
                defaultValue={selectedEntry?.compressedBiogas.o2 ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="N2 %"
                type="number"
                defaultValue={selectedEntry?.compressedBiogas.n2 ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="Conversion Ratio"
                type="number"
                defaultValue={selectedEntry?.compressedBiogas.conversionRatio ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="CH4 Slippage"
                type="number"
                defaultValue={selectedEntry?.compressedBiogas.ch4Slippage ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="CBG Stock"
                type="number"
                defaultValue={selectedEntry?.compressedBiogas.cbgStock ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                label="CBG Sold"
                type="number"
                defaultValue={selectedEntry?.compressedBiogas.cbgSold ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
          </Grid>
        </AccordionDetails>
      </Accordion>

      {/* Compressors */}
      <Accordion
        sx={{
          mb: 2,
          borderRadius: '12px !important',
          '&:before': { display: 'none' },
          overflow: 'hidden',
          boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
          border: '1px solid #e0e0e0',
        }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon sx={{ color: '#666' }} />}
          sx={{
            backgroundColor: '#f5f5f5',
            borderBottom: '1px solid #e0e0e0',
            minHeight: '56px',
            '&.Mui-expanded': {
              minHeight: '56px',
            },
          }}
        >
          <Typography sx={{ fontWeight: 600, color: '#333' }}>
            Compressors
          </Typography>
        </AccordionSummary>
        <AccordionDetails sx={{ p: 3, backgroundColor: '#fff' }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={4}>
              <TextField
                fullWidth
                label="Compressor 1 Hours"
                type="number"
                defaultValue={selectedEntry?.compressors.compressor1Hours ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField
                fullWidth
                label="Compressor 2 Hours"
                type="number"
                defaultValue={selectedEntry?.compressors.compressor2Hours ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField
                fullWidth
                label="Total Hours"
                type="number"
                defaultValue={selectedEntry?.compressors.totalHours ?? ''}
                disabled={isReadOnly}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
            </Grid>
          </Grid>
        </AccordionDetails>
      </Accordion>
    </>
  );
}
