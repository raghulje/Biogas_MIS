
import {
  Box,
  Typography,
  Button,
  Chip,
  IconButton,
} from '@mui/material';
import {
  Save as SaveIcon,
  Send as SendIcon,
  ArrowBack as ArrowBackIcon,
} from '@mui/icons-material';
import { MISEntry } from '../../../mocks/misEntries';
import RawMaterialsSection from './sections/RawMaterialsSection';
import FeedMixingTankSection from './sections/FeedMixingTankSection';
import DigestersSection from './sections/DigestersSection';
import SLSMachineSection from './sections/SLSMachineSection';
import BiogasSection from './sections/BiogasSection';
import OtherSections from './sections/OtherSections';

interface Digester {
  id: number;
  name: string;
  feeding: { totalSlurryFeed: number; avgTs: number; avgVs: number };
  discharge: { totalSlurryOut: number; avgTs: number; avgVs: number };
  characteristics: {
    lignin: number;
    vfa: number;
    alkalinity: number;
    vfaAlkRatio: number;
    ash: number;
    density: number;
    ph: number;
    temperature: number;
    pressure: number;
    slurryLevel: number;
  };
  health: {
    hrt: number;
    vsDestruction: number;
    olr: number;
    balloonLevel: number;
    agitatorCondition: string;
    foamingLevel: number;
  };
}

interface MISFormViewProps {
  viewMode: 'create' | 'edit' | 'view';
  selectedEntry: MISEntry | null;
  digesters: Digester[];
  onBackToList: () => void;
  onAddDigester: () => void;
  onRemoveDigester: (id: number) => void;
}

export default function MISFormView({
  viewMode,
  selectedEntry,
  digesters,
  onBackToList,
  onAddDigester,
  onRemoveDigester,
}: MISFormViewProps) {
  const isReadOnly = viewMode === 'view';

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Submitted':
        return { bg: 'rgba(40, 121, 182, 0.1)', color: '#2879b6' };
      case 'Approved':
        return { bg: 'rgba(125, 194, 68, 0.1)', color: '#7dc244' };
      case 'Draft':
        return { bg: 'rgba(245, 158, 33, 0.1)', color: '#F59E21' };
      default:
        return { bg: 'rgba(88, 89, 91, 0.1)', color: '#58595B' };
    }
  };

  return (
    <Box className="aos-fade-up">
      <Box
        sx={{
          mb: 3,
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: 2,
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <IconButton
            onClick={onBackToList}
            sx={{
              backgroundColor: 'rgba(40, 121, 182, 0.1)',
              borderRadius: '12px',
              '&:hover': { backgroundColor: 'rgba(40, 121, 182, 0.2)' },
            }}
          >
            <ArrowBackIcon sx={{ color: '#2879b6' }} />
          </IconButton>
          <Typography variant="h4" sx={{ fontWeight: 700, color: '#2879b6' }}>
            {viewMode === 'create'
              ? 'Create New MIS Entry'
              : viewMode === 'edit'
              ? `Edit: ${selectedEntry?.id}`
              : `View: ${selectedEntry?.id}`}
          </Typography>
          {selectedEntry && (
            <Chip
              label={selectedEntry.status}
              size="small"
              sx={{
                fontWeight: 600,
                backgroundColor: getStatusColor(selectedEntry.status).bg,
                color: getStatusColor(selectedEntry.status).color,
                borderRadius: '8px',
              }}
            />
          )}
        </Box>
        {!isReadOnly && (
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
            <Button
              variant="outlined"
              startIcon={<SaveIcon />}
              className="btn-gradient-warning"
              sx={{
                textTransform: 'none',
                borderRadius: '12px',
                border: 'none',
                color: '#fff',
                px: 3,
                whiteSpace: 'nowrap',
              }}
            >
              Save Draft
            </Button>
            <Button
              variant="contained"
              startIcon={<SendIcon />}
              className="btn-gradient-success"
              sx={{
                textTransform: 'none',
                borderRadius: '12px',
                color: '#fff',
                px: 3,
                whiteSpace: 'nowrap',
              }}
            >
              Submit
            </Button>
          </Box>
        )}
      </Box>

      <RawMaterialsSection selectedEntry={selectedEntry} isReadOnly={isReadOnly} />
      <FeedMixingTankSection selectedEntry={selectedEntry} isReadOnly={isReadOnly} />
      <DigestersSection
        digesters={digesters}
        isReadOnly={isReadOnly}
        onAddDigester={onAddDigester}
        onRemoveDigester={onRemoveDigester}
      />
      <SLSMachineSection selectedEntry={selectedEntry} isReadOnly={isReadOnly} />
      <BiogasSection selectedEntry={selectedEntry} isReadOnly={isReadOnly} />
      <OtherSections selectedEntry={selectedEntry} isReadOnly={isReadOnly} />

      {!isReadOnly && (
        <Box
          sx={{
            display: 'flex',
            gap: 2,
            justifyContent: 'flex-end',
            flexWrap: 'wrap',
            mt: 3,
          }}
        >
          <Button
            variant="outlined"
            startIcon={<SaveIcon />}
            size="large"
            className="btn-gradient-warning"
            sx={{
              textTransform: 'none',
              borderRadius: '12px',
              px: 4,
              border: 'none',
              color: '#fff',
              whiteSpace: 'nowrap',
            }}
          >
            Save Draft
          </Button>
          <Button
            variant="contained"
            startIcon={<SendIcon />}
            size="large"
            className="btn-gradient-success"
            sx={{
              textTransform: 'none',
              borderRadius: '12px',
              px: 4,
              color: '#fff',
              whiteSpace: 'nowrap',
            }}
          >
            Submit
          </Button>
        </Box>
      )}
    </Box>
  );
}
