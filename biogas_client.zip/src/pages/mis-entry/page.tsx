
import { useState, useEffect } from 'react';
import { Layout } from '../../components/Layout';
import { mockMISEntries, MISEntry } from '../../mocks/misEntries';
import MISListView from './components/MISListView';
import MISFormView from './components/MISFormView';

interface Digester {
  id: number;
  name: string;
  feeding: { totalSlurryFeed: number; avgTs: number; avgVs: number };
  discharge: { totalSlurryOut: number; avgTs: number; avgVs: number };
  characteristics: {
    lignin: number;
    vfa: number;
    alkalinity: number;
    vfaAlkRatio: number;
    ash: number;
    density: number;
    ph: number;
    temperature: number;
    pressure: number;
    slurryLevel: number;
  };
  health: {
    hrt: number;
    vsDestruction: number;
    olr: number;
    balloonLevel: number;
    agitatorCondition: string;
    foamingLevel: number;
  };
}

type ViewMode = 'list' | 'create' | 'edit' | 'view';

const defaultDigesters: Digester[] = [
  {
    id: 1,
    name: 'Digester 01',
    feeding: { totalSlurryFeed: 0, avgTs: 0, avgVs: 0 },
    discharge: { totalSlurryOut: 0, avgTs: 0, avgVs: 0 },
    characteristics: {
      lignin: 0,
      vfa: 0,
      alkalinity: 0,
      vfaAlkRatio: 0,
      ash: 0,
      density: 0,
      ph: 0,
      temperature: 0,
      pressure: 0,
      slurryLevel: 0,
    },
    health: {
      hrt: 0,
      vsDestruction: 0,
      olr: 0,
      balloonLevel: 0,
      agitatorCondition: 'OK',
      foamingLevel: 0,
    },
  },
  {
    id: 2,
    name: 'Digester 02',
    feeding: { totalSlurryFeed: 0, avgTs: 0, avgVs: 0 },
    discharge: { totalSlurryOut: 0, avgTs: 0, avgVs: 0 },
    characteristics: {
      lignin: 0,
      vfa: 0,
      alkalinity: 0,
      vfaAlkRatio: 0,
      ash: 0,
      density: 0,
      ph: 0,
      temperature: 0,
      pressure: 0,
      slurryLevel: 0,
    },
    health: {
      hrt: 0,
      vsDestruction: 0,
      olr: 0,
      balloonLevel: 0,
      agitatorCondition: 'OK',
      foamingLevel: 0,
    },
  },
  {
    id: 3,
    name: 'Digester 03',
    feeding: { totalSlurryFeed: 0, avgTs: 0, avgVs: 0 },
    discharge: { totalSlurryOut: 0, avgTs: 0, avgVs: 0 },
    characteristics: {
      lignin: 0,
      vfa: 0,
      alkalinity: 0,
      vfaAlkRatio: 0,
      ash: 0,
      density: 0,
      ph: 0,
      temperature: 0,
      pressure: 0,
      slurryLevel: 0,
    },
    health: {
      hrt: 0,
      vsDestruction: 0,
      olr: 0,
      balloonLevel: 0,
      agitatorCondition: 'OK',
      foamingLevel: 0,
    },
  },
];

export default function MISEntryPage() {
  const [viewMode, setViewMode] = useState<ViewMode>('list');
  const [entries, setEntries] = useState<MISEntry[]>(mockMISEntries);
  const [selectedEntry, setSelectedEntry] = useState<MISEntry | null>(null);
  const [digesters, setDigesters] = useState<Digester[]>(defaultDigesters);

  // Sync digesters when an entry is selected for edit or view
  useEffect(() => {
    if (selectedEntry && (viewMode === 'edit' || viewMode === 'view')) {
      // Guard against malformed entry data
      if (Array.isArray(selectedEntry.digesters)) {
        setDigesters(selectedEntry.digesters);
      } else {
        console.warn('Selected entry has no digesters array; falling back to defaults.');
        setDigesters(defaultDigesters);
      }
    }
  }, [selectedEntry, viewMode]);

  const addDigester = () => {
    const newId = digesters.length > 0 ? Math.max(...digesters.map((d) => d.id)) + 1 : 1;
    setDigesters([
      ...digesters,
      {
        id: newId,
        name: `Digester ${String(newId).padStart(2, '0')}`,
        feeding: { totalSlurryFeed: 0, avgTs: 0, avgVs: 0 },
        discharge: { totalSlurryOut: 0, avgTs: 0, avgVs: 0 },
        characteristics: {
          lignin: 0,
          vfa: 0,
          alkalinity: 0,
          vfaAlkRatio: 0,
          ash: 0,
          density: 0,
          ph: 0,
          temperature: 0,
          pressure: 0,
          slurryLevel: 0,
        },
        health: {
          hrt: 0,
          vsDestruction: 0,
          olr: 0,
          balloonLevel: 0,
          agitatorCondition: 'OK',
          foamingLevel: 0,
        },
      },
    ]);
  };

  const removeDigester = (id: number) => {
    if (digesters.length > 1) {
      setDigesters(digesters.filter((d) => d.id !== id));
    } else {
      console.warn('At least one digester must remain.');
    }
  };

  const handleEdit = (entry: MISEntry) => {
    setSelectedEntry(entry);
    setViewMode('edit');
  };

  const handleView = (entry: MISEntry) => {
    setSelectedEntry(entry);
    setViewMode('view');
  };

  const handleDelete = (entry: MISEntry) => {
    setEntries((prev) => prev.filter((e) => e.id !== entry.id));
  };

  const handleCreateNew = () => {
    setSelectedEntry(null);
    setDigesters(defaultDigesters);
    setViewMode('create');
  };

  const handleBackToList = () => {
    setViewMode('list');
    setSelectedEntry(null);
  };

  return (
    <Layout>
      {viewMode === 'list' ? (
        <MISListView
          entries={entries}
          onCreateNew={handleCreateNew}
          onEdit={handleEdit}
          onView={handleView}
          onDelete={handleDelete}
        />
      ) : (
        <MISFormView
          viewMode={viewMode}
          selectedEntry={selectedEntry}
          digesters={digesters}
          onBackToList={handleBackToList}
          onAddDigester={addDigester}
          onRemoveDigester={removeDigester}
        />
      )}
    </Layout>
  );
}
